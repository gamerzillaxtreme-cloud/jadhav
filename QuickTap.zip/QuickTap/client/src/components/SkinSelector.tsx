import { useSkins, SKINS } from '../lib/stores/useSkins';
import { useRunner } from '../lib/stores/useRunner';

export default function SkinSelector() {
  const { currentSkinId, unlockedSkins, setSkin } = useSkins();
  const highScore = useRunner(state => state.highScore);

  return (
    <div className="absolute bottom-20 left-0 right-0 flex flex-col items-center gap-3 px-4">
      <h3 className="text-white text-xl font-bold bg-black/50 px-4 py-2 rounded">
        Choose Your Character
      </h3>
      <div className="flex gap-3 overflow-x-auto pb-2 max-w-full">
        {SKINS.map((skin) => {
          const isUnlocked = unlockedSkins.includes(skin.id);
          const isSelected = currentSkinId === skin.id;
          
          return (
            <button
              key={skin.id}
              onClick={() => isUnlocked && setSkin(skin.id)}
              disabled={!isUnlocked}
              className={`
                flex flex-col items-center gap-2 p-3 rounded-lg min-w-[140px]
                transition-all transform hover:scale-105
                ${isSelected 
                  ? 'bg-gradient-to-b from-yellow-400 to-yellow-600 ring-4 ring-yellow-300' 
                  : isUnlocked 
                    ? 'bg-gradient-to-b from-gray-700 to-gray-800 hover:from-gray-600 hover:to-gray-700' 
                    : 'bg-gray-900 opacity-50 cursor-not-allowed'
                }
              `}
            >
              <div className="flex gap-1 items-end">
                <div 
                  className="w-8 h-12 rounded"
                  style={{ backgroundColor: skin.bodyColor }}
                />
                <div 
                  className="w-10 h-6 rounded"
                  style={{ backgroundColor: skin.headColor }}
                />
              </div>
              
              <div className="text-center">
                <p className={`font-bold text-sm ${isSelected ? 'text-black' : 'text-white'}`}>
                  {skin.name}
                </p>
                {!isUnlocked && (
                  <p className="text-xs text-red-400 mt-1">
                    Score {skin.unlockScore}+ to unlock
                  </p>
                )}
                {isUnlocked && !isSelected && (
                  <p className="text-xs text-gray-400 mt-1">
                    {skin.description}
                  </p>
                )}
                {isSelected && (
                  <p className="text-xs text-black font-semibold mt-1">
                    ✓ Selected
                  </p>
                )}
              </div>
            </button>
          );
        })}
      </div>
      <p className="text-white text-sm bg-black/50 px-3 py-1 rounded">
        Your High Score: {highScore}
      </p>
    </div>
  );
}
