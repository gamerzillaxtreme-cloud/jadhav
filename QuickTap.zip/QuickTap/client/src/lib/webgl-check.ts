export function isWebGLAvailable(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    return !!gl;
  } catch (e) {
    return false;
  }
}

export function getWebGLErrorMessage(): string {
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  
  if (isMobile) {
    return 'Your mobile browser may not support WebGL. Please try opening this game in Chrome or Safari.';
  }
  
  return 'WebGL is not available in this environment. Please open this game in a modern browser with WebGL support (Chrome, Firefox, Edge, or Safari).';
}
