import { useRunner } from '../lib/stores/useRunner';
import { useKeyboardControls } from '@react-three/drei';
import { useEffect } from 'react';

export default function GameOver() {
  const { restartGame, score, highScore, distance, coins } = useRunner();
  const [, getKeys] = useKeyboardControls();

  // Handle keyboard input for restarting
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ' || e.key === 'r' || e.key === 'R') {
        restartGame();
      }
    };

    window.addEventListener('keypress', handleKeyPress);
    return () => window.removeEventListener('keypress', handleKeyPress);
  }, [restartGame]);

  const isNewHighScore = score === highScore && score > 0;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100vw',
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      background: 'linear-gradient(135deg, #dc3545, #c82333, #a71e2a)',
      zIndex: 1000,
      fontFamily: 'Inter, sans-serif'
    }}>
      {/* Game Over Title */}
      <h1 style={{
        fontSize: '3.5rem',
        fontWeight: 'bold',
        color: 'white',
        textShadow: '3px 3px 6px rgba(0, 0, 0, 0.7)',
        marginBottom: '20px',
        textAlign: 'center'
      }}>
        💥 Game Over!
      </h1>

      {/* New High Score Celebration */}
      {isNewHighScore && (
        <div style={{
          background: 'linear-gradient(45deg, #FFD700, #FFA500)',
          padding: '20px 40px',
          borderRadius: '20px',
          marginBottom: '30px',
          animation: 'pulse 1s infinite'
        }}>
          <h2 style={{
            color: '#8B4513',
            fontSize: '1.8rem',
            fontWeight: 'bold',
            margin: 0,
            textAlign: 'center'
          }}>
            🎉 NEW HIGH SCORE! 🎉
          </h2>
        </div>
      )}

      {/* Score Statistics */}
      <div style={{
        background: 'rgba(0, 0, 0, 0.8)',
        padding: '30px 40px',
        borderRadius: '20px',
        marginBottom: '40px',
        textAlign: 'center',
        minWidth: '300px'
      }}>
        <div style={{
          color: '#FFD700',
          fontSize: '2rem',
          fontWeight: 'bold',
          marginBottom: '15px'
        }}>
          Final Score: {score}
        </div>
        
        <div style={{ color: 'white', fontSize: '1.2rem', lineHeight: '1.8' }}>
          <p style={{ margin: '10px 0' }}>
            <span style={{ opacity: 0.8 }}>Distance:</span> <strong>{Math.floor(distance)}m</strong>
          </p>
          <p style={{ margin: '10px 0' }}>
            <span style={{ opacity: 0.8 }}>Coins:</span> <strong>{coins} 🪙</strong>
          </p>
          <p style={{ margin: '10px 0' }}>
            <span style={{ opacity: 0.8 }}>Best Score:</span> <strong style={{ color: '#FFD700' }}>{highScore}</strong>
          </p>
        </div>
      </div>

      {/* Motivational Message */}
      <div style={{
        background: 'rgba(255, 255, 255, 0.9)',
        padding: '20px 30px',
        borderRadius: '15px',
        marginBottom: '40px',
        textAlign: 'center',
        maxWidth: '400px'
      }}>
        <p style={{
          color: '#333',
          fontSize: '1.1rem',
          margin: 0,
          fontStyle: 'italic'
        }}>
          {score > 1000 
            ? "Incredible run! You're a true temple runner! 🏃‍♂️✨"
            : score > 500
            ? "Great job! Keep practicing to master the temple! 🏛️"
            : "Don't give up! Every legend starts with practice! 💪"
          }
        </p>
      </div>

      {/* Restart Button */}
      <button
        onClick={restartGame}
        style={{
          background: 'linear-gradient(45deg, #28a745, #20c997)',
          border: 'none',
          padding: '20px 50px',
          fontSize: '1.5rem',
          fontWeight: 'bold',
          color: 'white',
          borderRadius: '50px',
          cursor: 'pointer',
          boxShadow: '0 8px 20px rgba(0, 0, 0, 0.3)',
          transition: 'all 0.3s ease',
          textTransform: 'uppercase',
          letterSpacing: '1px'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'scale(1.05)';
          e.currentTarget.style.boxShadow = '0 10px 25px rgba(0, 0, 0, 0.4)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'scale(1)';
          e.currentTarget.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.3)';
        }}
      >
        🔄 Try Again
      </button>

      <p style={{
        color: 'white',
        marginTop: '20px',
        fontSize: '1rem',
        opacity: 0.8,
        textAlign: 'center'
      }}>
        Press Enter, Space, or R to restart
      </p>

      {/* CSS Animation for new high score */}
      <style>{`
        @keyframes pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.05); }
          100% { transform: scale(1); }
        }
      `}</style>
    </div>
  );
}
