import { useRunner } from '../lib/stores/useRunner';
import { useAudio } from '../lib/stores/useAudio';

export default function GameUI() {
  const { 
    gameState, 
    score, 
    distance, 
    coins, 
    speed,
    hasSpeedBoost,
    hasCoinMagnet,
    hasInvincibility 
  } = useRunner();
  const { isMuted, toggleMute } = useAudio();

  if (gameState !== 'playing') return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      padding: '20px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      zIndex: 1000,
      pointerEvents: 'none',
      fontFamily: 'Inter, sans-serif'
    }}>
      {/* Score and stats */}
      <div style={{
        background: 'rgba(0, 0, 0, 0.8)',
        padding: '15px 20px',
        borderRadius: '10px',
        color: 'white',
        fontSize: '18px',
        fontWeight: 'bold'
      }}>
        <div style={{ marginBottom: '5px' }}>Score: {score}</div>
        <div style={{ marginBottom: '5px' }}>Distance: {Math.floor(distance)}m</div>
        <div style={{ marginBottom: '5px' }}>Coins: {coins}</div>
        <div style={{ fontSize: '14px', opacity: 0.8 }}>Speed: {speed.toFixed(1)}</div>
      </div>

      {/* Power-ups status */}
      <div style={{
        background: 'rgba(255, 255, 255, 0.9)',
        padding: '15px 20px',
        borderRadius: '10px',
        color: '#333',
        fontSize: '14px',
        textAlign: 'right'
      }}>
        <div style={{ fontWeight: 'bold', marginBottom: '10px' }}>Active Power-ups:</div>
        {hasSpeedBoost && <div style={{ color: '#00FFFF', fontWeight: 'bold' }}>⚡ Speed Boost</div>}
        {hasCoinMagnet && <div style={{ color: '#FF00FF', fontWeight: 'bold' }}>🧲 Coin Magnet</div>}
        {hasInvincibility && <div style={{ color: '#FFD700', fontWeight: 'bold' }}>⭐ Invincibility</div>}
        {!hasSpeedBoost && !hasCoinMagnet && !hasInvincibility && (
          <div style={{ opacity: 0.5, fontStyle: 'italic' }}>None</div>
        )}
        <div style={{ marginTop: '10px', fontSize: '12px', opacity: 0.7 }}>
          Collect power-ups to boost your run!
        </div>
      </div>

      {/* Sound toggle */}
      <button
        onClick={toggleMute}
        style={{
          position: 'fixed',
          bottom: '20px',
          right: '20px',
          background: isMuted ? 'rgba(255, 0, 0, 0.8)' : 'rgba(0, 255, 0, 0.8)',
          border: 'none',
          borderRadius: '50%',
          width: '50px',
          height: '50px',
          color: 'white',
          fontSize: '16px',
          cursor: 'pointer',
          pointerEvents: 'auto',
          zIndex: 1001
        }}
      >
        {isMuted ? '🔇' : '🔊'}
      </button>
    </div>
  );
}
