# Temple Runner - Indian Edition

## Overview
An addictive endless runner game inspired by Temple Run, featuring vibrant Indian cities and villages as backgrounds. Players dodge rickshaws, cows, market stalls, and vendors while collecting golden coins.

## Game Features
- **3-lane endless runner** with intuitive controls
- **Indian-themed obstacles**: rickshaws, cows, market stalls, street vendors
- **Coin collection system** with trails and bonus points
- **Progressive difficulty** - speed increases with distance
- **High score tracking** with local storage persistence
- **Responsive controls** - keyboard controls for desktop

## Controls
- **A/D or ←/→**: Switch lanes (left/right)
- **W or Space**: Jump over obstacles
- **S or ↓**: Slide under barriers
- **Enter**: Start/restart game
- **M**: Toggle sound

## Recent Changes
- **Oct 4, 2025**: Initial game implementation with Indian theming
  - Created Temple Run-style endless runner mechanics
  - Added Indian-themed obstacles and environment
  - Implemented coin collection and scoring system
  - Added WebGL detection with fallback UI

## Technical Notes

### WebGL Support
⚠️ **Important**: This game requires WebGL to run. The Replit preview pane may not support WebGL in all configurations.

**If you see a WebGL error:**
1. Click "Open in new tab" at the top of the Replit preview
2. Ensure you're using a modern browser (Chrome, Firefox, Edge, Safari)
3. Check that hardware acceleration is enabled in browser settings

The game includes automatic WebGL detection and displays a helpful error message when WebGL is unavailable.

### Project Architecture
- **Frontend**: React + Three.js + React Three Fiber
- **Game State**: Zustand for state management
- **3D Rendering**: @react-three/fiber with custom components
- **Controls**: @react-three/drei KeyboardControls
- **Styling**: Tailwind CSS + inline styles for game UI

### Key Files
- `client/src/components/Game.tsx` - Main game loop
- `client/src/components/Player.tsx` - Player movement and physics
- `client/src/components/Obstacles.tsx` - Obstacle spawning and collision
- `client/src/components/Environment.tsx` - Indian-themed environment
- `client/src/lib/stores/useRunner.tsx` - Game state management
- `client/src/lib/webgl-check.ts` - WebGL detection utility

## User Preferences
None specified yet.

## Future Enhancements
- Multiple themed environments (Taj Mahal, Mumbai streets, Kerala villages)
- Power-ups (speed boost, magnet, invincibility)
- Unlockable characters in traditional Indian attire
- Seasonal themes (Diwali, Holi effects)
- Leaderboard and score sharing
