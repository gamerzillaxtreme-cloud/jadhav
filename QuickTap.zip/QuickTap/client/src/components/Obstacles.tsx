import { useRef, useMemo, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { useRunner, type Obstacle, type Lane } from '../lib/stores/useRunner';
import { useAudio } from '../lib/stores/useAudio';
import * as THREE from 'three';

export default function Obstacles() {
  const { 
    gameState, 
    obstacles, 
    addObstacle, 
    removeObstacle,
    speed,
    currentLane,
    isJumping,
    isSliding,
    hasInvincibility,
    endGame
  } = useRunner();
  const { playHit } = useAudio();
  
  const groupRef = useRef<THREE.Group>(null);
  const lastSpawnTime = useRef(0);

  // Pre-calculated obstacle data to avoid Math.random in render
  // Using vibrant Indian color palette
  const obstacleTypes = useMemo(() => [
    { type: 'rickshaw' as const, color: '#FFD700', size: [2, 1.5, 3] as [number, number, number] }, // Golden yellow rickshaw
    { type: 'cow' as const, color: '#F8F8F8', size: [1.5, 1.2, 2.5] as [number, number, number] }, // White/cream sacred cow
    { type: 'stall' as const, color: '#FF6B35', size: [2.5, 2, 1.5] as [number, number, number] }, // Vibrant orange market stall
    { type: 'vendor' as const, color: '#138808', size: [1, 2, 1] as [number, number, number] } // Green (from Indian flag) vendor
  ], []);

  // Spawn obstacles
  useFrame((state) => {
    if (gameState !== 'playing') return;

    const currentTime = state.clock.elapsedTime;
    const spawnInterval = Math.max(0.8, 2 - speed * 0.05); // Faster spawning as speed increases

    if (currentTime - lastSpawnTime.current > spawnInterval) {
      const lanes: Lane[] = [-1, 0, 1];
      const randomLane = lanes[Math.floor(Math.random() * lanes.length)];
      const randomType = obstacleTypes[Math.floor(Math.random() * obstacleTypes.length)];
      
      const obstacle: Obstacle = {
        id: `obstacle-${currentTime}-${Math.random()}`,
        position: [randomLane * 4, 0, -50],
        type: randomType.type,
        lane: randomLane
      };

      addObstacle(obstacle);
      lastSpawnTime.current = currentTime;
    }
  });

  // Move obstacles and check collisions
  useFrame((state, delta) => {
    if (gameState !== 'playing' || !groupRef.current) return;

    // Move obstacles toward player
    obstacles.forEach((obstacle) => {
      const mesh = groupRef.current?.getObjectByName(obstacle.id) as THREE.Mesh;
      if (mesh) {
        mesh.position.z += speed * delta;
        
        // Remove obstacles that are behind the player
        if (mesh.position.z > 10) {
          removeObstacle(obstacle.id);
        }

        // Collision detection
        if (mesh.position.z > -2 && mesh.position.z < 2) {
          const playerLaneX = currentLane * 4;
          const obstacleX = obstacle.position[0];
          
          // Check if player is in same lane as obstacle
          if (Math.abs(playerLaneX - obstacleX) < 1.5) {
            let collision = false;
            
            // Check vertical collision based on obstacle type
            if (obstacle.type === 'stall' || obstacle.type === 'rickshaw') {
              // These are tall obstacles - can jump over
              if (!isJumping || mesh.position.y < 2) {
                collision = true;
              }
            } else if (obstacle.type === 'vendor') {
              // Can slide under or jump over
              if (!isJumping && !isSliding) {
                collision = true;
              }
            } else if (obstacle.type === 'cow') {
              // Must jump over cows
              if (!isJumping) {
                collision = true;
              }
            }

            if (collision) {
              if (hasInvincibility) {
                console.log('Collision blocked by invincibility!');
                // Remove the obstacle when invincible
                removeObstacle(obstacle.id);
              } else {
                console.log('Collision detected!');
                playHit();
                endGame();
              }
            }
          }
        }
      }
    });
  });

  // Render obstacles
  const obstacleElements = obstacles.map((obstacle) => {
    const obstacleData = obstacleTypes.find(t => t.type === obstacle.type);
    if (!obstacleData) return null;

    let yPosition = obstacleData.size[1] / 2;
    
    // Adjust Y position for different obstacle types
    if (obstacle.type === 'cow') {
      yPosition = 0.6; // Cows are closer to ground
    } else if (obstacle.type === 'vendor') {
      yPosition = 1; // Standing vendors
    }

    return (
      <mesh
        key={obstacle.id}
        name={obstacle.id}
        position={[obstacle.position[0], yPosition, obstacle.position[2]]}
        castShadow
        receiveShadow
      >
        <boxGeometry args={obstacleData.size} />
        <meshLambertMaterial color={obstacleData.color} />
      </mesh>
    );
  });

  return (
    <group ref={groupRef}>
      {obstacleElements}
    </group>
  );
}
