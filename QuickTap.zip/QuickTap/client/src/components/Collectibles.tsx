import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useRunner, type Coin, type Lane } from '../lib/stores/useRunner';
import { useAudio } from '../lib/stores/useAudio';
import * as THREE from 'three';

export default function Collectibles() {
  const { 
    gameState, 
    collectibles, 
    addCoin, 
    removeCoin,
    collectCoin,
    speed,
    currentLane,
    hasCoinMagnet
  } = useRunner();
  const { playSuccess } = useAudio();
  
  const groupRef = useRef<THREE.Group>(null);
  const lastSpawnTime = useRef(0);

  // Spawn coins
  useFrame((state) => {
    if (gameState !== 'playing') return;

    const currentTime = state.clock.elapsedTime;
    const spawnInterval = 1.5; // Coin spawn rate

    if (currentTime - lastSpawnTime.current > spawnInterval) {
      // Sometimes spawn coin trails
      if (Math.random() > 0.3) {
        const lanes: Lane[] = [-1, 0, 1];
        const randomLane = lanes[Math.floor(Math.random() * lanes.length)];
        
        // Spawn a trail of coins
        for (let i = 0; i < 3; i++) {
          const coin: Coin = {
            id: `coin-${currentTime}-${i}-${Math.random()}`,
            position: [randomLane * 4, 2 + Math.sin(i) * 0.5, -50 - i * 3],
            collected: false,
            lane: randomLane
          };
          addCoin(coin);
        }
      } else {
        // Single coin
        const lanes: Lane[] = [-1, 0, 1];
        const randomLane = lanes[Math.floor(Math.random() * lanes.length)];
        
        const coin: Coin = {
          id: `coin-${currentTime}-${Math.random()}`,
          position: [randomLane * 4, 2.5, -50],
          collected: false,
          lane: randomLane
        };
        addCoin(coin);
      }
      
      lastSpawnTime.current = currentTime;
    }
  });

  // Move coins and check collection
  useFrame((state, delta) => {
    if (gameState !== 'playing' || !groupRef.current) return;

    collectibles.forEach((coin) => {
      if (coin.collected) return;
      
      const mesh = groupRef.current?.getObjectByName(coin.id) as THREE.Mesh;
      if (mesh) {
        // Move coin toward player
        mesh.position.z += speed * delta;
        
        // Animate coin (spinning and floating)
        mesh.rotation.y += delta * 4;
        mesh.position.y = coin.position[1] + Math.sin(state.clock.elapsedTime * 3 + coin.position[2]) * 0.3;
        
        // Remove coins that are behind the player
        if (mesh.position.z > 10) {
          removeCoin(coin.id);
        }

        // Collection detection (wider range with coin magnet)
        const collectionRange = hasCoinMagnet ? 6 : 2;
        if (mesh.position.z > -2 && mesh.position.z < 2) {
          const playerLaneX = currentLane * 4;
          const coinX = coin.position[0];
          
          // Check if player is close enough to collect
          if (Math.abs(playerLaneX - coinX) < collectionRange) {
            console.log('Coin collected!');
            collectCoin(coin.id);
            playSuccess();
            
            // Hide the collected coin
            mesh.visible = false;
          }
        }
      }
    });
  });

  // Render coins
  const coinElements = collectibles.map((coin) => {
    if (coin.collected) return null;

    return (
      <mesh
        key={coin.id}
        name={coin.id}
        position={coin.position}
        castShadow
      >
        <cylinderGeometry args={[0.4, 0.4, 0.1, 8]} />
        <meshLambertMaterial color="#FFD700" emissive="#FFD700" emissiveIntensity={0.2} />
      </mesh>
    );
  });

  return (
    <group ref={groupRef}>
      {coinElements}
    </group>
  );
}
