import { useState, useEffect, useRef } from 'react';
import { useSkins, SKINS } from '../lib/stores/useSkins';

export default function UnlockNotification() {
  const [notifications, setNotifications] = useState<string[]>([]);
  const prevUnlockedRef = useRef<string[]>(useSkins.getState().unlockedSkins);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const unsubscribe = useSkins.subscribe((state) => {
      const newUnlocked = state.unlockedSkins;
      const prevUnlocked = prevUnlockedRef.current;
      
      const newlyUnlocked = newUnlocked.filter((id: string) => !prevUnlocked.includes(id));
      if (newlyUnlocked.length > 0) {
        const newNotifications = newlyUnlocked.map((skinId: string) => {
          const unlockedSkin = SKINS.find(s => s.id === skinId);
          return unlockedSkin ? `🎉 New skin unlocked: ${unlockedSkin.name}!` : '';
        }).filter(Boolean);
        
        if (newNotifications.length > 0) {
          if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
          }
          
          setNotifications(newNotifications);
          timeoutRef.current = setTimeout(() => {
            setNotifications([]);
            timeoutRef.current = null;
          }, 4000);
        }
      }
      
      prevUnlockedRef.current = newUnlocked;
    });

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      unsubscribe();
    };
  }, []);

  if (notifications.length === 0) return null;

  return (
    <div style={{
      position: 'fixed',
      top: '80px',
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 2000,
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      alignItems: 'center'
    }}>
      {notifications.map((notification, index) => (
        <div
          key={index}
          style={{
            background: 'linear-gradient(to right, #FBBF24, #F59E0B)',
            color: 'black',
            fontWeight: 'bold',
            padding: '12px 24px',
            borderRadius: '9999px',
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.3)',
            border: '4px solid #FCD34D',
            animation: 'bounce 1s infinite'
          }}
        >
          {notification}
        </div>
      ))}
    </div>
  );
}
