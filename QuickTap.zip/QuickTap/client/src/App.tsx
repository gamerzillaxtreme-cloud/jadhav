import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { KeyboardControls } from "@react-three/drei";
import { useRunner } from "./lib/stores/useRunner";
import { useAudio } from "./lib/stores/useAudio";
import Game from "./components/Game";
import Menu from "./components/Menu";
import GameOver from "./components/GameOver";
import GameUI from "./components/GameUI";
import UnlockNotification from "./components/UnlockNotification";
import { isWebGLAvailable, getWebGLErrorMessage } from "./lib/webgl-check";
import "@fontsource/inter";

// Define control keys for the runner game
const controls = [
  { name: "left", keys: ["KeyA", "ArrowLeft"] },
  { name: "right", keys: ["KeyD", "ArrowRight"] },
  { name: "jump", keys: ["KeyW", "ArrowUp", "Space"] },
  { name: "slide", keys: ["KeyS", "ArrowDown"] },
  { name: "start", keys: ["Enter"] },
  { name: "restart", keys: ["KeyR"] },
];

function App() {
  const { gameState } = useRunner();
  const { toggleMute } = useAudio();
  const [showCanvas, setShowCanvas] = useState(false);
  const [hasWebGL, setHasWebGL] = useState(true);

  // Check WebGL availability and initialize
  useEffect(() => {
    const webglAvailable = isWebGLAvailable();
    setHasWebGL(webglAvailable);
    
    if (!webglAvailable) {
      console.warn('WebGL is not available in this environment');
      return;
    }

    const initAudio = async () => {
      try {
        const backgroundMusic = new Audio("/sounds/background.mp3");
        backgroundMusic.loop = true;
        backgroundMusic.volume = 0.3;
        
        const hitSound = new Audio("/sounds/hit.mp3");
        hitSound.volume = 0.4;
        
        const successSound = new Audio("/sounds/success.mp3");
        successSound.volume = 0.5;
        
        // Store audio references in the audio store
        useAudio.getState().setBackgroundMusic(backgroundMusic);
        useAudio.getState().setHitSound(hitSound);
        useAudio.getState().setSuccessSound(successSound);
        
        console.log("Audio initialized");
      } catch (error) {
        console.log("Audio initialization failed:", error);
      }
    };

    initAudio();
    setShowCanvas(true);
  }, []);

  // Handle global key events
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === 'm' || e.key === 'M') {
        toggleMute();
      }
    };

    window.addEventListener('keypress', handleKeyPress);
    return () => window.removeEventListener('keypress', handleKeyPress);
  }, [toggleMute]);

  // Show WebGL unavailable message
  if (!hasWebGL) {
    return (
      <div style={{ 
        width: '100vw', 
        height: '100vh', 
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        background: 'linear-gradient(135deg, #FF6B35, #F7931E, #FFD700)',
        fontFamily: 'Inter, sans-serif',
        padding: '20px',
        textAlign: 'center'
      }}>
        <h1 style={{
          fontSize: '3rem',
          fontWeight: 'bold',
          color: 'white',
          textShadow: '3px 3px 6px rgba(0, 0, 0, 0.5)',
          marginBottom: '30px'
        }}>
          🏛️ Temple Runner
        </h1>
        
        <div style={{
          background: 'rgba(255, 255, 255, 0.95)',
          padding: '40px',
          borderRadius: '20px',
          maxWidth: '600px',
          boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)'
        }}>
          <h2 style={{
            color: '#dc3545',
            fontSize: '1.8rem',
            marginBottom: '20px'
          }}>
            ⚠️ WebGL Not Available
          </h2>
          
          <p style={{
            color: '#333',
            fontSize: '1.1rem',
            lineHeight: '1.6',
            marginBottom: '20px'
          }}>
            {getWebGLErrorMessage()}
          </p>
          
          <div style={{
            background: '#f8f9fa',
            padding: '20px',
            borderRadius: '10px',
            marginTop: '20px'
          }}>
            <h3 style={{
              color: '#495057',
              fontSize: '1.2rem',
              marginBottom: '15px'
            }}>
              How to play this game:
            </h3>
            <ol style={{
              color: '#6c757d',
              textAlign: 'left',
              lineHeight: '1.8',
              fontSize: '1rem',
              paddingLeft: '20px'
            }}>
              <li>Open this game in a new browser tab with WebGL support</li>
              <li>If using Replit, click "Open in new tab" button at the top</li>
              <li>Try using Chrome, Firefox, Edge, or Safari</li>
              <li>Make sure hardware acceleration is enabled in your browser settings</li>
            </ol>
          </div>

          <p style={{
            color: '#666',
            fontSize: '0.9rem',
            marginTop: '20px',
            fontStyle: 'italic'
          }}>
            Note: The Replit preview pane may not support WebGL. Opening in a new tab usually resolves this issue.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ 
      width: '100vw', 
      height: '100vh', 
      position: 'relative', 
      overflow: 'hidden',
      background: 'linear-gradient(to bottom, #87CEEB 0%, #98FB98 100%)'
    }}>
      {showCanvas && (
        <KeyboardControls map={controls}>
          {gameState === 'menu' && <Menu />}
          {gameState === 'gameOver' && <GameOver />}
          <GameUI />
          <UnlockNotification />
          
          <Canvas
            shadows
            camera={{
              position: [0, 8, 10],
              fov: 60,
              near: 0.1,
              far: 1000
            }}
            gl={{
              antialias: true,
              powerPreference: "high-performance"
            }}
          >
            <color attach="background" args={["#87CEEB"]} />
            
            {/* Lighting */}
            <directionalLight
              position={[10, 15, 5]}
              intensity={1.2}
              castShadow
              shadow-mapSize={[2048, 2048]}
              shadow-camera-far={50}
              shadow-camera-left={-20}
              shadow-camera-right={20}
              shadow-camera-top={20}
              shadow-camera-bottom={-20}
            />
            <ambientLight intensity={0.4} />
            <hemisphereLight args={["#87CEEB", "#8B4513", 0.6]} />

            <Suspense fallback={null}>
              <Game />
            </Suspense>
          </Canvas>
        </KeyboardControls>
      )}
    </div>
  );
}

export default App;
