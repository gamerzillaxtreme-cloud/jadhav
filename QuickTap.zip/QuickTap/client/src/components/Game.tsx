import { useEffect, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useRunner } from '../lib/stores/useRunner';
import Player from './Player';
import Environment from './Environment';
import Obstacles from './Obstacles';
import Collectibles from './Collectibles';
import PowerUps from './PowerUps';

export default function Game() {
  const { gameState, updateDistance, speed } = useRunner();
  const lastTimeRef = useRef(0);

  // Main game loop
  useFrame((state, delta) => {
    if (gameState !== 'playing') return;
    
    // Update distance based on speed
    updateDistance(speed * delta);
    
    // Move camera to follow player with slight lag
    const targetZ = 10;
    state.camera.position.z += (targetZ - state.camera.position.z) * 0.1;
  });

  return (
    <>
      <Environment />
      <Player />
      <Obstacles />
      <Collectibles />
      <PowerUps />
    </>
  );
}
