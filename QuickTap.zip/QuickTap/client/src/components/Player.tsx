import { useRef, useEffect, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { useKeyboardControls } from '@react-three/drei';
import { useRunner } from '../lib/stores/useRunner';
import { useAudio } from '../lib/stores/useAudio';
import { useSkins } from '../lib/stores/useSkins';
import * as THREE from 'three';

export default function Player() {
  const meshRef = useRef<THREE.Group>(null);
  const { currentLane, isJumping, isSliding, setJumping, setSliding, gameState, endGame } = useRunner();
  const { playHit } = useAudio();
  const currentSkin = useSkins(state => state.getCurrentSkin());
  
  const [, getKeys] = useKeyboardControls();
  const [position, setPosition] = useState<[number, number, number]>([0, 1, 0]);
  const [jumpVelocity, setJumpVelocity] = useState(0);
  const [jumpStartTime, setJumpStartTime] = useState(0);

  // Convert lane to X position
  const getLaneX = (lane: number) => lane * 4;

  // Handle input
  useFrame((state, delta) => {
    if (gameState !== 'playing') return;

    const keys = getKeys();
    
    // Handle lane switching
    const targetX = getLaneX(currentLane);
    const currentX = position[0];
    const newX = THREE.MathUtils.lerp(currentX, targetX, delta * 10);

    // Handle jumping physics
    let newY = position[1];
    let newJumpVelocity = jumpVelocity;
    
    if (isJumping) {
      const jumpTime = state.clock.elapsedTime - jumpStartTime;
      const jumpHeight = 6;
      const jumpDuration = 1;
      
      if (jumpTime < jumpDuration) {
        newY = 1 + Math.sin((jumpTime / jumpDuration) * Math.PI) * jumpHeight;
      } else {
        newY = 1;
        setJumping(false);
      }
    } else if (keys.jump && !isSliding) {
      setJumping(true);
      setJumpStartTime(state.clock.elapsedTime);
    }

    // Handle sliding
    if (isSliding) {
      newY = 0.3;
      // Auto-stop sliding after short duration
      setTimeout(() => setSliding(false), 800);
    } else if (keys.slide && !isJumping) {
      setSliding(true);
    }

    setPosition([newX, newY, position[2]]);
  });

  // Check collisions with obstacles
  useFrame(() => {
    if (!meshRef.current || gameState !== 'playing') return;

    const playerBox = new THREE.Box3().setFromObject(meshRef.current);
    
    // You would check collision with obstacles here
    // This is handled in the Obstacles component
  });

  return (
    <group ref={meshRef} position={position}>
      {/* Main player body */}
      <mesh 
        castShadow
        receiveShadow
      >
        <boxGeometry args={[1, 2, 1]} />
        <meshLambertMaterial color={currentSkin.bodyColor} />
      </mesh>
      {/* Decorative head/turban */}
      <mesh position={[0, 1.3, 0]} castShadow>
        <boxGeometry args={[1.2, 0.6, 1.2]} />
        <meshLambertMaterial color={currentSkin.headColor} />
      </mesh>
    </group>
  );
}
