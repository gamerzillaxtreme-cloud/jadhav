import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type GameState = "menu" | "playing" | "gameOver";
export type Lane = -1 | 0 | 1; // left, center, right
export type EnvironmentTheme = 'village' | 'tajMahal' | 'mumbai' | 'rajasthan';

export interface Obstacle {
  id: string;
  position: [number, number, number];
  type: 'rickshaw' | 'cow' | 'stall' | 'vendor';
  lane: Lane;
}

export interface Coin {
  id: string;
  position: [number, number, number];
  collected: boolean;
  lane: Lane;
}

export type PowerUpType = 'speedBoost' | 'coinMagnet' | 'invincibility';

export interface PowerUp {
  id: string;
  position: [number, number, number];
  type: PowerUpType;
  collected: boolean;
  lane: Lane;
}

interface RunnerState {
  gameState: GameState;
  score: number;
  highScore: number;
  distance: number;
  coins: number;
  speed: number;
  baseSpeed: number;
  currentLane: Lane;
  isJumping: boolean;
  isSliding: boolean;
  obstacles: Obstacle[];
  collectibles: Coin[];
  powerUps: PowerUp[];
  currentEnvironment: EnvironmentTheme;
  
  // Power-up states
  hasSpeedBoost: boolean;
  hasCoinMagnet: boolean;
  hasInvincibility: boolean;
  speedBoostEndTime: number;
  coinMagnetEndTime: number;
  invincibilityEndTime: number;
  
  // Player actions
  moveLeft: () => void;
  moveRight: () => void;
  jump: () => void;
  slide: () => void;
  
  // Game actions
  startGame: () => void;
  endGame: () => void;
  restartGame: () => void;
  updateDistance: (delta: number) => void;
  collectCoin: (coinId: string) => void;
  
  // Obstacle management
  addObstacle: (obstacle: Obstacle) => void;
  addCoin: (coin: Coin) => void;
  removeObstacle: (id: string) => void;
  removeCoin: (id: string) => void;
  clearObstacles: () => void;
  
  // Power-up management
  addPowerUp: (powerUp: PowerUp) => void;
  removePowerUp: (id: string) => void;
  collectPowerUp: (powerUpId: string) => void;
  updatePowerUpStates: (currentTime: number) => void;
  
  // Physics
  setJumping: (jumping: boolean) => void;
  setSliding: (sliding: boolean) => void;
}

export const useRunner = create<RunnerState>()(
  subscribeWithSelector((set, get) => ({
    gameState: "menu",
    score: 0,
    highScore: parseInt(localStorage.getItem('templeRunHighScore') || '0'),
    distance: 0,
    coins: 0,
    speed: 10,
    baseSpeed: 10,
    currentLane: 0,
    isJumping: false,
    isSliding: false,
    obstacles: [],
    collectibles: [],
    powerUps: [],
    currentEnvironment: 'village' as EnvironmentTheme,
    
    // Power-up states
    hasSpeedBoost: false,
    hasCoinMagnet: false,
    hasInvincibility: false,
    speedBoostEndTime: 0,
    coinMagnetEndTime: 0,
    invincibilityEndTime: 0,
    
    moveLeft: () => {
      set((state) => {
        if (state.gameState !== 'playing') return {};
        const newLane = Math.max(-1, state.currentLane - 1) as Lane;
        console.log('Moving left to lane:', newLane);
        return { currentLane: newLane };
      });
    },
    
    moveRight: () => {
      set((state) => {
        if (state.gameState !== 'playing') return {};
        const newLane = Math.min(1, state.currentLane + 1) as Lane;
        console.log('Moving right to lane:', newLane);
        return { currentLane: newLane };
      });
    },
    
    jump: () => {
      const state = get();
      if (state.gameState !== 'playing' || state.isJumping || state.isSliding) return;
      console.log('Jumping');
      set({ isJumping: true });
      // Jump will be handled by physics in Player component
    },
    
    slide: () => {
      const state = get();
      if (state.gameState !== 'playing' || state.isJumping || state.isSliding) return;
      console.log('Sliding');
      set({ isSliding: true });
      // Slide will be handled by physics in Player component
    },
    
    startGame: () => {
      console.log('Starting game');
      set({
        gameState: "playing",
        score: 0,
        distance: 0,
        coins: 0,
        speed: 10,
        baseSpeed: 10,
        currentLane: 0,
        isJumping: false,
        isSliding: false,
        obstacles: [],
        collectibles: [],
        powerUps: [],
        currentEnvironment: 'village',
        hasSpeedBoost: false,
        hasCoinMagnet: false,
        hasInvincibility: false,
        speedBoostEndTime: 0,
        coinMagnetEndTime: 0,
        invincibilityEndTime: 0
      });
      
      // Start background music when game starts
      import('../stores/useAudio').then(({ useAudio }) => {
        useAudio.getState().startBackgroundMusic();
      });
    },
    
    endGame: () => {
      const state = get();
      const newHighScore = Math.max(state.score, state.highScore);
      localStorage.setItem('templeRunHighScore', newHighScore.toString());
      console.log('Game ended. Score:', state.score, 'High Score:', newHighScore);
      set({
        gameState: "gameOver",
        highScore: newHighScore
      });
      
      // Stop background music when game ends
      import('../stores/useAudio').then(({ useAudio }) => {
        useAudio.getState().stopBackgroundMusic();
      });
    },
    
    restartGame: () => {
      get().startGame();
    },
    
    updateDistance: (delta: number) => {
      set((state) => {
        if (state.gameState !== 'playing') return {};
        const newDistance = state.distance + delta;
        const newBaseSpeed = Math.min(25, 10 + Math.floor(newDistance / 100) * 2);
        const newScore = Math.floor(newDistance) + state.coins * 10;
        
        // Check for skin unlocks
        import('../stores/useSkins').then(({ useSkins }) => {
          useSkins.getState().checkUnlocks(newScore);
        });
        
        // Calculate actual speed with power-up multiplier
        const actualSpeed = state.hasSpeedBoost ? newBaseSpeed * 1.5 : newBaseSpeed;
        
        // Change environment based on distance
        let newEnvironment: EnvironmentTheme = state.currentEnvironment;
        if (newDistance >= 500 && state.currentEnvironment !== 'rajasthan') {
          newEnvironment = 'rajasthan';
          console.log('Environment changed to: Rajasthan Desert');
        } else if (newDistance >= 300 && state.currentEnvironment !== 'mumbai') {
          newEnvironment = 'mumbai';
          console.log('Environment changed to: Mumbai Streets');
        } else if (newDistance >= 150 && state.currentEnvironment !== 'tajMahal') {
          newEnvironment = 'tajMahal';
          console.log('Environment changed to: Taj Mahal');
        }
        
        return {
          distance: newDistance,
          baseSpeed: newBaseSpeed,
          speed: actualSpeed,
          score: newScore,
          currentEnvironment: newEnvironment
        };
      });
    },
    
    collectCoin: (coinId: string) => {
      set((state) => {
        const coin = state.collectibles.find(c => c.id === coinId);
        if (!coin || coin.collected) return {};
        
        console.log('Collected coin!');
        return {
          coins: state.coins + 1,
          collectibles: state.collectibles.map(c =>
            c.id === coinId ? { ...c, collected: true } : c
          )
        };
      });
    },
    
    addObstacle: (obstacle: Obstacle) => {
      set((state) => ({
        obstacles: [...state.obstacles, obstacle]
      }));
    },
    
    addCoin: (coin: Coin) => {
      set((state) => ({
        collectibles: [...state.collectibles, coin]
      }));
    },
    
    removeObstacle: (id: string) => {
      set((state) => ({
        obstacles: state.obstacles.filter(o => o.id !== id)
      }));
    },
    
    removeCoin: (id: string) => {
      set((state) => ({
        collectibles: state.collectibles.filter(c => c.id !== id)
      }));
    },
    
    clearObstacles: () => {
      set({ obstacles: [], collectibles: [], powerUps: [] });
    },
    
    // Power-up management
    addPowerUp: (powerUp: PowerUp) => {
      set((state) => ({
        powerUps: [...state.powerUps, powerUp]
      }));
    },
    
    removePowerUp: (id: string) => {
      set((state) => ({
        powerUps: state.powerUps.filter(p => p.id !== id)
      }));
    },
    
    collectPowerUp: (powerUpId: string) => {
      const state = get();
      const powerUp = state.powerUps.find(p => p.id === powerUpId);
      if (!powerUp || powerUp.collected) return;
      
      const currentTime = Date.now();
      const duration = 5000; // 5 seconds
      
      console.log(`Collected ${powerUp.type} power-up!`);
      
      switch (powerUp.type) {
        case 'speedBoost':
          set({
            hasSpeedBoost: true,
            speedBoostEndTime: currentTime + duration,
            speed: state.baseSpeed * 1.5
          });
          break;
        case 'coinMagnet':
          set({
            hasCoinMagnet: true,
            coinMagnetEndTime: currentTime + duration
          });
          break;
        case 'invincibility':
          set({
            hasInvincibility: true,
            invincibilityEndTime: currentTime + duration
          });
          break;
      }
      
      set((state) => ({
        powerUps: state.powerUps.map(p =>
          p.id === powerUpId ? { ...p, collected: true } : p
        )
      }));
    },
    
    updatePowerUpStates: (currentTime: number) => {
      const state = get();
      const updates: Partial<RunnerState> = {};
      
      if (state.hasSpeedBoost && currentTime > state.speedBoostEndTime) {
        updates.hasSpeedBoost = false;
        updates.speed = state.baseSpeed;
        console.log('Speed boost ended');
      }
      
      if (state.hasCoinMagnet && currentTime > state.coinMagnetEndTime) {
        updates.hasCoinMagnet = false;
        console.log('Coin magnet ended');
      }
      
      if (state.hasInvincibility && currentTime > state.invincibilityEndTime) {
        updates.hasInvincibility = false;
        console.log('Invincibility ended');
      }
      
      if (Object.keys(updates).length > 0) {
        set(updates);
      }
    },
    
    setJumping: (jumping: boolean) => {
      set({ isJumping: jumping });
    },
    
    setSliding: (sliding: boolean) => {
      set({ isSliding: sliding });
    }
  }))
);
