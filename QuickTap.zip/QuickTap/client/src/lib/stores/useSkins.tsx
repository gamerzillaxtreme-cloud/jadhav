import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Skin {
  id: string;
  name: string;
  bodyColor: string;
  headColor: string;
  unlockScore: number;
  description: string;
}

export const SKINS: Skin[] = [
  {
    id: 'classic',
    name: 'Classic Runner',
    bodyColor: '#FF9933',
    headColor: '#DC143C',
    unlockScore: 0,
    description: 'The original runner with saffron body and red turban'
  },
  {
    id: 'kerala',
    name: 'Kerala Mundu',
    bodyColor: '#FFFFFF',
    headColor: '#DAA520',
    unlockScore: 200,
    description: 'Traditional Kerala white mundu with golden kasavu border'
  },
  {
    id: 'rajasthan',
    name: 'Rajasthani Royal',
    bodyColor: '#DC143C',
    headColor: '#FFD700',
    unlockScore: 500,
    description: 'Royal Rajasthani attire in crimson red with golden turban'
  },
  {
    id: 'punjab',
    name: 'Punjabi Bhangra',
    bodyColor: '#FF6B35',
    headColor: '#138808',
    unlockScore: 1000,
    description: 'Vibrant Punjabi outfit in orange with green turban'
  }
];

interface SkinsState {
  currentSkinId: string;
  unlockedSkins: string[];
  
  getCurrentSkin: () => Skin;
  setSkin: (skinId: string) => void;
  unlockSkin: (skinId: string) => void;
  checkUnlocks: (score: number) => void;
}

export const useSkins = create<SkinsState>()(
  persist(
    (set, get) => ({
      currentSkinId: 'classic',
      unlockedSkins: ['classic'],
      
      getCurrentSkin: () => {
        const currentId = get().currentSkinId;
        return SKINS.find(s => s.id === currentId) || SKINS[0];
      },
      
      setSkin: (skinId: string) => {
        const { unlockedSkins } = get();
        if (unlockedSkins.includes(skinId)) {
          set({ currentSkinId: skinId });
          console.log(`Switched to skin: ${skinId}`);
        } else {
          console.log(`Skin ${skinId} is locked`);
        }
      },
      
      unlockSkin: (skinId: string) => {
        set((state) => {
          if (!state.unlockedSkins.includes(skinId)) {
            console.log(`Unlocked new skin: ${skinId}`);
            return {
              unlockedSkins: [...state.unlockedSkins, skinId]
            };
          }
          return state;
        });
      },
      
      checkUnlocks: (score: number) => {
        const { unlockedSkins, unlockSkin } = get();
        SKINS.forEach(skin => {
          if (score >= skin.unlockScore && !unlockedSkins.includes(skin.id)) {
            unlockSkin(skin.id);
          }
        });
      }
    }),
    {
      name: 'indian-runner-skins'
    }
  )
);
