package com.flappysnake.arcade;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
