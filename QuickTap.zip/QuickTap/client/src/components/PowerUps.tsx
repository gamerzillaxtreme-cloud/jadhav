import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useRunner, type PowerUp, type PowerUpType, type Lane } from '../lib/stores/useRunner';
import * as THREE from 'three';

export default function PowerUps() {
  const { 
    gameState, 
    powerUps, 
    addPowerUp, 
    removePowerUp,
    collectPowerUp,
    updatePowerUpStates,
    speed,
    currentLane,
    hasCoinMagnet
  } = useRunner();
  
  const groupRef = useRef<THREE.Group>(null);
  const lastSpawnTime = useRef(0);

  // Power-up configurations
  const powerUpTypes = useMemo(() => [
    { 
      type: 'speedBoost' as PowerUpType, 
      color: '#00FFFF',  // Cyan
      emissive: '#00FFFF',
      icon: '⚡' 
    },
    { 
      type: 'coinMagnet' as PowerUpType, 
      color: '#FF00FF',  // Magenta
      emissive: '#FF00FF',
      icon: '🧲' 
    },
    { 
      type: 'invincibility' as PowerUpType, 
      color: '#FFD700',  // Gold
      emissive: '#FFA500',
      icon: '⭐' 
    }
  ], []);

  // Spawn power-ups
  useFrame((state) => {
    if (gameState !== 'playing') return;

    const currentTime = state.clock.elapsedTime;
    const spawnInterval = 8; // Power-ups spawn every 8 seconds

    if (currentTime - lastSpawnTime.current > spawnInterval) {
      const lanes: Lane[] = [-1, 0, 1];
      const randomLane = lanes[Math.floor(Math.random() * lanes.length)];
      const randomType = powerUpTypes[Math.floor(Math.random() * powerUpTypes.length)];
      
      const powerUp: PowerUp = {
        id: `powerup-${currentTime}-${Math.random()}`,
        position: [randomLane * 4, 2, -50],
        type: randomType.type,
        collected: false,
        lane: randomLane
      };

      addPowerUp(powerUp);
      lastSpawnTime.current = currentTime;
    }

    // Update power-up states (check for expiration)
    updatePowerUpStates(Date.now());
  });

  // Move power-ups and check collection
  useFrame((state, delta) => {
    if (gameState !== 'playing' || !groupRef.current) return;

    powerUps.forEach((powerUp) => {
      if (powerUp.collected) return;
      
      const mesh = groupRef.current?.getObjectByName(powerUp.id) as THREE.Mesh;
      if (mesh) {
        // Move power-up toward player
        mesh.position.z += speed * delta;
        
        // Animate power-up (spinning and floating)
        mesh.rotation.y += delta * 3;
        mesh.rotation.x = Math.sin(state.clock.elapsedTime * 2) * 0.2;
        mesh.position.y = powerUp.position[1] + Math.sin(state.clock.elapsedTime * 2) * 0.5;
        
        // Remove power-ups that are behind the player
        if (mesh.position.z > 10) {
          removePowerUp(powerUp.id);
        }

        // Collection detection (wider range for coin magnet)
        const collectionRange = hasCoinMagnet ? 4 : 2;
        if (mesh.position.z > -2 && mesh.position.z < 2) {
          const playerLaneX = currentLane * 4;
          const powerUpX = powerUp.position[0];
          
          // Check if player is close enough to collect
          if (Math.abs(playerLaneX - powerUpX) < collectionRange) {
            console.log(`Power-up collected: ${powerUp.type}`);
            collectPowerUp(powerUp.id);
            
            // Hide the collected power-up
            mesh.visible = false;
          }
        }
      }
    });
  });

  // Render power-ups
  const powerUpElements = powerUps.map((powerUp) => {
    if (powerUp.collected) return null;
    
    const config = powerUpTypes.find(t => t.type === powerUp.type);
    if (!config) return null;

    return (
      <mesh
        key={powerUp.id}
        name={powerUp.id}
        position={powerUp.position}
        castShadow
      >
        <octahedronGeometry args={[0.6, 0]} />
        <meshStandardMaterial 
          color={config.color} 
          emissive={config.emissive} 
          emissiveIntensity={0.5}
          metalness={0.5}
          roughness={0.2}
        />
      </mesh>
    );
  });

  return (
    <group ref={groupRef}>
      {powerUpElements}
    </group>
  );
}
