import { useRunner } from '../lib/stores/useRunner';
import { useKeyboardControls } from '@react-three/drei';
import { useEffect } from 'react';
import SkinSelector from './SkinSelector';

export default function Menu() {
  const { startGame, highScore } = useRunner();
  const [, getKeys] = useKeyboardControls();

  // Handle keyboard input for starting game
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        startGame();
      }
    };

    window.addEventListener('keypress', handleKeyPress);
    return () => window.removeEventListener('keypress', handleKeyPress);
  }, [startGame]);

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100vw',
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      background: 'linear-gradient(135deg, #FF6B35, #F7931E, #FFD700)',
      zIndex: 1000,
      fontFamily: 'Inter, sans-serif'
    }}>
      {/* Title */}
      <h1 style={{
        fontSize: '4rem',
        fontWeight: 'bold',
        color: 'white',
        textShadow: '3px 3px 6px rgba(0, 0, 0, 0.5)',
        marginBottom: '20px',
        textAlign: 'center'
      }}>
        🏛️ Temple Runner
      </h1>

      <h2 style={{
        fontSize: '1.5rem',
        color: 'white',
        textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)',
        marginBottom: '40px',
        textAlign: 'center'
      }}>
        Endless Indian Adventure
      </h2>

      {/* High Score */}
      {highScore > 0 && (
        <div style={{
          background: 'rgba(0, 0, 0, 0.7)',
          padding: '15px 30px',
          borderRadius: '15px',
          marginBottom: '30px'
        }}>
          <p style={{
            color: '#FFD700',
            fontSize: '1.2rem',
            fontWeight: 'bold',
            margin: 0
          }}>
            Best Score: {highScore}
          </p>
        </div>
      )}

      {/* Instructions */}
      <div style={{
        background: 'rgba(255, 255, 255, 0.9)',
        padding: '30px',
        borderRadius: '15px',
        marginBottom: '40px',
        textAlign: 'center',
        maxWidth: '500px'
      }}>
        <h3 style={{ color: '#333', marginBottom: '20px', fontSize: '1.3rem' }}>
          How to Play:
        </h3>
        <div style={{ color: '#555', fontSize: '1rem', lineHeight: '1.6' }}>
          <p><strong>A/D or Arrow Keys</strong> - Switch lanes</p>
          <p><strong>W or Space</strong> - Jump over obstacles</p>
          <p><strong>S or Down Arrow</strong> - Slide under barriers</p>
          <p style={{ marginTop: '20px', fontSize: '0.9rem', fontStyle: 'italic' }}>
            Avoid rickshaws, cows, market stalls, and vendors!<br/>
            Collect golden coins for bonus points! 🪙
          </p>
        </div>
      </div>

      {/* Start Button */}
      <button
        onClick={startGame}
        style={{
          background: 'linear-gradient(45deg, #28a745, #20c997)',
          border: 'none',
          padding: '20px 50px',
          fontSize: '1.5rem',
          fontWeight: 'bold',
          color: 'white',
          borderRadius: '50px',
          cursor: 'pointer',
          boxShadow: '0 8px 20px rgba(0, 0, 0, 0.3)',
          transition: 'all 0.3s ease',
          textTransform: 'uppercase',
          letterSpacing: '1px'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'scale(1.05)';
          e.currentTarget.style.boxShadow = '0 10px 25px rgba(0, 0, 0, 0.4)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'scale(1)';
          e.currentTarget.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.3)';
        }}
      >
        🚀 Start Running!
      </button>

      <p style={{
        color: 'white',
        marginTop: '20px',
        fontSize: '1rem',
        opacity: 0.8
      }}>
        Press Enter or Space to start
      </p>
      
      <SkinSelector />
    </div>
  );
}
