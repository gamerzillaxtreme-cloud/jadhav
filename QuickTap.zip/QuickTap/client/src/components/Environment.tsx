import { useRef, useMemo } from 'react';
import { useFrame, useLoader } from '@react-three/fiber';
import { TextureLoader } from 'three';
import { useRunner } from '../lib/stores/useRunner';
import * as THREE from 'three';

export default function Environment() {
  const { gameState, speed, currentEnvironment } = useRunner();
  const roadRef = useRef<THREE.Group>(null);
  
  // Load textures
  const grassTexture = useLoader(TextureLoader, '/textures/grass.png');
  const asphaltTexture = useLoader(TextureLoader, '/textures/asphalt.png');
  const sandTexture = useLoader(TextureLoader, '/textures/sand.jpg');

  // Configure texture repeating
  useMemo(() => {
    [grassTexture, asphaltTexture, sandTexture].forEach(texture => {
      texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
      texture.repeat.set(4, 20);
    });
  }, [grassTexture, asphaltTexture, sandTexture]);

  // Theme-specific configurations
  const themeConfig = useMemo(() => {
    switch (currentEnvironment) {
      case 'village':
        return {
          colors: ['#8B4513', '#D2691E', '#228B22', '#CD853F', '#DAA520'],
          skyColor: '#87CEEB',
          sideColor: '#DAA520',
          buildingStyle: 'traditional'
        };
      case 'tajMahal':
        return {
          colors: ['#FFFFFF', '#F5F5DC', '#FFE4B5', '#E6E6FA', '#B0C4DE'],
          skyColor: '#B0E0E6',
          sideColor: '#F5F5DC',
          buildingStyle: 'marble'
        };
      case 'mumbai':
        return {
          colors: ['#FF6B35', '#004E98', '#FFD700', '#1A535C', '#F7B801'],
          skyColor: '#708090',
          sideColor: '#696969',
          buildingStyle: 'modern'
        };
      case 'rajasthan':
        return {
          colors: ['#FF9933', '#DC143C', '#FFD700', '#FF6347', '#FFA500'],
          skyColor: '#F4A460',
          sideColor: '#DEB887',
          buildingStyle: 'desert'
        };
      default:
        return {
          colors: ['#FF9933', '#FFFFFF', '#138808'],
          skyColor: '#87CEEB',
          sideColor: '#DAA520',
          buildingStyle: 'traditional'
        };
    }
  }, [currentEnvironment]);

  // Background elements with environment-specific theming
  const backgroundElements = useMemo(() => {
    const elements = [];
    
    for (let i = 0; i < 15; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (15 + Math.random() * 15);
      const z = -i * 15 - Math.random() * 10;
      const height = currentEnvironment === 'mumbai' ? 8 + Math.random() * 15 : 3 + Math.random() * 10;
      const colorIndex = Math.floor(Math.random() * themeConfig.colors.length);
      
      // Environment-specific buildings
      if (currentEnvironment === 'tajMahal' && i % 5 === 0) {
        // Dome structures for Taj Mahal theme
        elements.push(
          <group key={`dome-${i}`} position={[x, 0, z]}>
            <mesh position={[0, height / 2, 0]} castShadow>
              <boxGeometry args={[4, height, 4]} />
              <meshLambertMaterial color="#FFFFFF" />
            </mesh>
            <mesh position={[0, height + 2, 0]} castShadow>
              <sphereGeometry args={[2, 8, 8]} />
              <meshLambertMaterial color="#F5F5DC" />
            </mesh>
          </group>
        );
      } else {
        // Standard buildings
        elements.push(
          <group key={`building-${i}`} position={[x, 0, z]}>
            <mesh position={[0, height / 2, 0]} castShadow>
              <boxGeometry args={[3, height, 3]} />
              <meshLambertMaterial color={themeConfig.colors[colorIndex]} />
            </mesh>
            {currentEnvironment !== 'rajasthan' && (
              <mesh position={[0, height + 0.3, 0]} castShadow>
                <boxGeometry args={[3.5, 0.6, 3.5]} />
                <meshLambertMaterial color={themeConfig.colors[(colorIndex + 1) % themeConfig.colors.length]} />
              </mesh>
            )}
          </group>
        );
      }

      // Environment-specific vegetation
      if (i % 3 === 0) {
        if (currentEnvironment === 'rajasthan') {
          // Cactus for desert
          elements.push(
            <group key={`cactus-${i}`} position={[x + side * 5, 0, z]}>
              <mesh position={[0, 2, 0]} castShadow>
                <cylinderGeometry args={[0.4, 0.4, 4]} />
                <meshLambertMaterial color="#2D6E2D" />
              </mesh>
              <mesh position={[-0.8, 2.5, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
                <cylinderGeometry args={[0.3, 0.3, 1.5]} />
                <meshLambertMaterial color="#2D6E2D" />
              </mesh>
            </group>
          );
        } else {
          // Trees for other environments
          elements.push(
            <group key={`tree-${i}`} position={[x + side * 5, 0, z]}>
              <mesh position={[0, 5, 0]} castShadow>
                <coneGeometry args={[1.5, 3, 6]} />
                <meshLambertMaterial color="#228B22" />
              </mesh>
              <mesh position={[0, 2.5, 0]} castShadow>
                <cylinderGeometry args={[0.3, 0.4, 5]} />
                <meshLambertMaterial color="#8B4513" />
              </mesh>
            </group>
          );
        }
      }

      // Decorative elements
      if (i % 4 === 0 && currentEnvironment !== 'rajasthan') {
        elements.push(
          <mesh key={`flag-${i}`} position={[x, 2, z + 2]} castShadow>
            <boxGeometry args={[0.1, 1.5, 1]} />
            <meshLambertMaterial color={themeConfig.colors[0]} side={THREE.DoubleSide} />
          </mesh>
        );
      }
    }
    return elements;
  }, [currentEnvironment, themeConfig]);

  // Create road segments with Indian street styling
  const roadSegments = useMemo(() => {
    const segments = [];
    for (let i = 0; i < 20; i++) {
      segments.push(
        <group key={i} position={[0, 0, -i * 10]}>
          {/* Main road */}
          <mesh position={[0, -0.1, 0]} receiveShadow>
            <boxGeometry args={[12, 0.2, 10]} />
            <meshLambertMaterial map={asphaltTexture} />
          </mesh>
          
          {/* Colorful side pathways (theme-specific) */}
          <mesh position={[-8, -0.05, 0]} receiveShadow>
            <boxGeometry args={[4, 0.1, 10]} />
            <meshLambertMaterial color={themeConfig.sideColor} />
          </mesh>
          <mesh position={[8, -0.05, 0]} receiveShadow>
            <boxGeometry args={[4, 0.1, 10]} />
            <meshLambertMaterial color={themeConfig.sideColor} />
          </mesh>

          {/* Lane dividers with Indian flag colors */}
          <mesh position={[-2, 0.01, 0]}>
            <boxGeometry args={[0.3, 0.03, 10]} />
            <meshLambertMaterial color="#FF9933" /> {/* Saffron */}
          </mesh>
          <mesh position={[2, 0.01, 0]}>
            <boxGeometry args={[0.3, 0.03, 10]} />
            <meshLambertMaterial color="#138808" /> {/* Green */}
          </mesh>
        </group>
      );
    }
    return segments;
  }, [asphaltTexture, themeConfig]);

  // Move road segments to create infinite effect
  useFrame((state, delta) => {
    if (gameState !== 'playing' || !roadRef.current) return;
    
    roadRef.current.children.forEach((segment, index) => {
      segment.position.z += speed * delta;
      
      // Reset segment position when it goes behind camera
      if (segment.position.z > 20) {
        segment.position.z = -180;
      }
    });
  });

  return (
    <>
      {/* Road segments */}
      <group ref={roadRef}>
        {roadSegments}
      </group>
      
      {/* Background elements */}
      {backgroundElements}
      
      {/* Sky dome with theme-specific color */}
      <mesh position={[0, 50, -50]} scale={[100, 100, 100]}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshBasicMaterial 
          color={themeConfig.skyColor} 
          side={THREE.BackSide}
        />
      </mesh>
    </>
  );
}
